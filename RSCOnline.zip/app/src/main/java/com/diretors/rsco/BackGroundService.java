package com.diretors.rsco;
import android.app.*;
import android.os.*;
import android.content.*;
import android.database.sqlite.*;
import java.util.*;

public class BackGroundService extends IntentService
{

	private MinistryRecordsOpenDbHelper dbHelper;
	private SQLiteDatabase db;
	
	@Override
	protected void onHandleIntent(Intent param)
	{
		// TODO: Implement this method
		dbHelper = new MinistryRecordsOpenDbHelper(this);
		db = dbHelper.getWritableDatabase();
		
		Bundle records = param.getExtras();
		
		insertDataIntoDb(records);
		
	}


	public BackGroundService(){
		super("BackGroundService");
	}
	
	private void  insertDataIntoDb(Bundle records) throws RuntimeException {
		//check the bundle if not null or empty then insert data into table
		int data = records.getInt("data");
		ArrayList<String> list = records.getStringArrayList("values");
		
		ContentValues values = new ContentValues();
		values.put("data",data);
		values.put("publicacoes",list.get(0).toString());
		values.put("videos",list.get(1).toString());
		values.put("revisitas",list.get(2).toString());
		values.put("estudos",list.get(3).toString());
		values.put("horas",list.get(4).toString());
		values.put("nota",list.get(5).toString());
		
		db.beginTransaction();
		db.insert("MinistryRecords",null, values);
		db.endTransaction();
		db.close();
		
	}
	
}
