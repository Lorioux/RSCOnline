package com.diretors.rsco;
import android.arch.persistence.room.*;

@Entity
public class RecordsEntity
{
}
