package com.diretors.rsco;
import android.content.*;
import android.database.sqlite.*;

import com.diretors.rsco.MinistryRecordsContract.*;

public class MinistryRecordsOpenDbHelper extends SQLiteOpenHelper
{
	private static final String DB_NAME = "mrecords.db";
	private static final int DB_VERSION = 1;
	
	private static final String TABLE_NAME = "MinistryRecords";
	
	private static final String SQLST_CT = "create table " + TABLE_NAME + " ("
		+ RecordEntries._ID +" integer auto_increment," 
		+ RecordEntries.COLUMN_DATA + " integer not null,"
		+ RecordEntries.COLUMN_PUB + " text,"
		+ RecordEntries.COLUMN_VID + " text,"
		+ RecordEntries.COLUMN_REV + " text,"
		+ RecordEntries.COLUMN_EST + " text,"
		+ RecordEntries.COLUMN_HRS + " text,"
		+ RecordEntries.COLUMN_NOTA + " text,"
		+ " primary key (" + RecordEntries._ID + ")"
	+") ;";//COMMENTS 'A tabela para o registo da informação do serviço do campo.'
	
	public MinistryRecordsOpenDbHelper(Context c){
		super(c, DB_NAME, null, DB_VERSION);
	}
	

	@Override
	public void onCreate(SQLiteDatabase db)
	{
		// TODO: Create a table in to the db
		
		db.execSQL(SQLST_CT);
		
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldv, int newv)
	{
		// TODO:
		db.execSQL("drop table " + TABLE_NAME + " if exists;");
		db.execSQL(SQLST_CT);
		
	}

}
