package com.diretors.rsco;
import android.arch.persistence.room.*;
import android.arch.persistence.db.*;

@Database
public class RecordsDataBase extends RoomDatabase
{

	@Override
	protected SupportSQLiteOpenHelper createOpenHelper(DatabaseConfiguration p1)
	{
		// TODO: Implement this method
		return null;
	}

	@Override
	protected InvalidationTracker createInvalidationTracker()
	{
		// TODO: Implement this method
		return null;
	}

	@Override
	public void clearAllTables()
	{
		// TODO: Implement this method
	}

	
}
