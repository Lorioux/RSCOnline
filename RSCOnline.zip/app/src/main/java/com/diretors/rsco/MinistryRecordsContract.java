package com.diretors.rsco;
import android.net.*;
import android.provider.*;
import java.net.*;

public class MinistryRecordsContract
{
//	private final String BASE_URI = "";
//	private final String URI_AUTHORITY = "";
//	private String CONTENT_URI = "";
	 
	public MinistryRecordsContract(){}
	
//	public Uri getUrl(){
//		Uri uri = Uri.parse("");
//		return uri;
//	}
//	
//	public void buildUriFromDate(Long date){
//		
//	}
//	
//	public void buildQueryRecordsFromDate(Long date){
//		
//	}
	
	public static class RecordEntries implements BaseColumns{
		public static final String COLUMN_DATA = "data";
		public static final String COLUMN_PUB = "publicacoes";
		public static final String COLUMN_VID = "videos";
		public static final String COLUMN_REV = "revisitas";
		public static final String COLUMN_EST = "estudos";
		public static final String COLUMN_HRS = "horas";
		public static final String COLUMN_NOTA = "nota";
	}
}
