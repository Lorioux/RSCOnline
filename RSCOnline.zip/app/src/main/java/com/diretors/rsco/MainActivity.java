package com.diretors.rsco;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity 
{
	private int data;
	private DatePicker mData;
	private EditText mPub, mVid, mRev, mEst, mHrs, mNota;
	private Button  mGuarda;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		mData = findViewById(R.id.mainDatePicker);
		mPub  = findViewById(R.id.mainPub);
		mVid  = findViewById(R.id.mainVid);
		mRev  = findViewById(R.id.mainRev);
		mEst  = findViewById(R.id.mainEst);
		mHrs  = findViewById(R.id.mainHrs);
		mNota = findViewById(R.id.mainMemo);
		mGuarda = findViewById(R.id.mainGuarda);
		
		mGuarda.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				guardarRegisto(v);
			}
		});
		
    }
	
	public void guardarRegisto(View v){
		
		data = mData.getDayOfMonth();
		
		Bundle records = getValuesFromViews();
		
		if (null != records){
			
			records.putInt("data", data);

			Class service = BackGroundService.class;
			Intent guarda = new Intent(this, service);
			guarda.putExtras(records);

			startService(guarda);
			
		}
		
	}

	private Bundle getValuesFromViews()
	{
		// TODO: Implement this method
		String no_pub = mPub.getText().toString();
		String no_vid = mVid.getText().toString();
		String no_rev = mRev.getText().toString();
		String no_est = mEst.getText().toString();
		String no_hrs = mHrs.getText().toString();
		String memo = mNota.getText().toString();
		
		ArrayList<String> values = new ArrayList ();
		values.add(no_pub);
		values.add(no_vid);
		values.add(no_rev);
		values.add(no_est);
		values.add(no_hrs);
		values.add(memo);
		
		//verificar se nenhum campo está vazio.
		for(int i = 0; i < values.size(); i++){
			if(values.get(i).isEmpty()){
				Toast.makeText(this,"Make sure that all fields are filled!", Toast.LENGTH_SHORT).show();
				return null;
			}
		}
		
		Bundle bundle = new Bundle();
		bundle.putStringArrayList("values", values);
		
		return bundle;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// TODO: Implement this method
		getMenuInflater().inflate(R.menu.menu, menu);
		return true;
	
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO: Implement this method
		int id = item.getItemId();
		if(R.id.action_report == id){
			
			Dialog dialog = new Dialog(this);
		
			
			dialog.setTitle("Relatório Do Mês");
			dialog.setContentView(R.layout.report_table);
			dialog.create();
			dialog.show();
			return true;
		}
		
		return super.onOptionsItemSelected(item);
	}
	
	
}
