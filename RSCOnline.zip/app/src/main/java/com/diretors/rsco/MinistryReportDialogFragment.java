package com.diretors.rsco;
import android.app.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class MinistryReportDialogFragment extends DialogFragment
{

	public MinistryReportDialogFragment(){}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// Inflate the layout here
		View v = inflater.from(getContext()).inflate(R.layout.report_table, container, false);
		
		return v;
	}
	
}
