package com.diretors.rsco;

import android.arch.persistence.room.*;

@Dao
public class RecordsDbDao
{
}
